setwd("C:\\Users\\IT24102441\\Desktop\\it24102441\\Lab 5")

##importing the data set
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")

# View the imported data
fix(Delivery_Times)

# Attach the data frame to easily call variables by name
attach(Delivery_Times)

# Check the class name for the delivery times column
names(Delivery_Times)

# The seq() function creates a sequence of numbers from 20 to 70 with 10 values.
hist_breaks <- seq(20, 70, length.out = 10)

hist_data <- hist(Delivery_Time_.minutes., main = "Histogram for Delivery Times", 
                  xlab = "Delivery Time (minutes)", ylab = "Frequency",
                  breaks = hist_breaks, right = FALSE)

# Part 3: 
#observation: The distribution appears to be skewed to the right (positively skewed)


# Part 4: Draw a cumulative frequency polygon
cum_freq <- cumsum(hist_data$counts)
breaks <- hist_data$breaks


# Create a new vector for the cumulative frequencies
new_cum_freq <- c(0, cum_freq)

# Draw the ogive
plot(breaks, new_cum_freq, type = "o", main = "Cumulative Frequency Polygon for Delivery Times",
     xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency",
     ylim = c(0, max(new_cum_freq)))


