setwd("C:/Users/Administrator/Desktop/it24102441/lab6")

#Q1(ii)
# Probability that at least 47 passed
1 - pbinom(46, size = 50, prob = 0.85)


#Q2(iii)
dpois(15, lambda = 12)


